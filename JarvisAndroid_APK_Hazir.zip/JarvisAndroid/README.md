# JARVIS Android

Özellikler:
- Türkçe sesli komut
- Türkçe sesli yanıt
- YouTube / Spotify / Google açma
- Müzik uygulamasını açma
- İstanbul hava durumunu Open-Meteo üzerinden gösterme
- Mikrofon izni

Kurulum:
1. Android Studio'da bu klasörü aç.
2. Gradle senkronizasyonunun bitmesini bekle.
3. Telefonunda USB hata ayıklama açıkken Run'a bas.
4. İlk açılışta mikrofon izni ver.

Not: Bu sürüm internetsiz bir yapay zekâ değildir; komutlar önceden tanımlıdır. Daha gelişmiş JARVIS için bir AI API/yerel model ve arka planda "Jarvis" tetikleme sistemi eklenebilir.

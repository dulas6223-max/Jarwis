# JARVIS APK oluşturma

Bu proje GitHub Actions ile APK oluşturabilir.

1. GitHub'da yeni bir repository oluştur.
2. Bu klasördeki dosyaların tamamını repository'ye yükle.
3. GitHub'da Actions sekmesine gir.
4. "Build JARVIS APK" iş akışını seç.
5. "Run workflow" düğmesine bas.
6. İşlem tamamlanınca Actions çalışmasının altındaki Artifacts bölümünden `JARVIS-debug-APK` dosyasını indir.
7. ZIP'i açıp `app-debug.apk` dosyasını Android telefona gönder.
8. APK'yi açıp kurulumu onayla.

Not: Bu debug APK imzalı mağaza sürümü değildir. Telefona manuel kurulum için kullanılabilir.

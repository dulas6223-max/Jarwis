package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private TextView status, weather;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        weather = findViewById(R.id.weather);

        tts = new TextToSpeech(this, s -> {
            if (s == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("tr", "TR"));
                speak("Merhaba. Ben Jarvis. Hazırım.");
            }
        });

        findViewById(R.id.talkButton).setOnClickListener(v -> listen());
        findViewById(R.id.weatherButton).setOnClickListener(v -> getWeather());
        findViewById(R.id.musicButton).setOnClickListener(v -> openMusic());
    }

    private void listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Bu telefonda sesli tanıma kullanılamıyor.");
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b){ status.setText("Dinliyorum..."); }
            public void onBeginningOfSpeech(){ }
            public void onRmsChanged(float r){ }
            public void onBufferReceived(byte[] b){ }
            public void onEndOfSpeech(){ status.setText("İşliyorum..."); }
            public void onError(int e){ status.setText("Hazırım."); }
            public void onPartialResults(Bundle b){ }
            public void onEvent(int a, Bundle b){ }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) handleCommand(r.get(0).toLowerCase(new Locale("tr","TR")));
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizer.startListening(i);
    }

    private void handleCommand(String c) {
        status.setText("Sen: " + c);
        if (c.contains("hava") || c.contains("hava durumu")) {
            getWeather(); return;
        }
        if (c.contains("müzik") || c.contains("şarkı")) {
            openMusic(); return;
        }
        if (c.contains("youtube")) {
            openPackageOrWeb("com.google.android.youtube", "https://www.youtube.com", "YouTube'u açıyorum.");
            return;
        }
        if (c.contains("spotify")) {
            openPackageOrWeb("com.spotify.music", "https://open.spotify.com", "Spotify'ı açıyorum.");
            return;
        }
        if (c.contains("google")) {
            openPackageOrWeb("com.google.android.googlequicksearchbox", "https://www.google.com", "Google'ı açıyorum.");
            return;
        }
        speak("Komutunu anladım: " + c + ". Bu komut için henüz bir eylem tanımlanmadı.");
    }

    private void openPackageOrWeb(String pkg, String web, String msg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) startActivity(i);
            else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(web)));
            speak(msg);
        } catch(Exception e) { speak("Uygulamayı açamadım."); }
    }

    private void openMusic() {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_APP_MUSIC);
            startActivity(i);
            speak("Müzik uygulamasını açıyorum.");
        } catch(Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com")));
            speak("Müzik için web oynatıcısını açıyorum.");
        }
    }

    private void getWeather() {
        status.setText("Hava durumu alınıyor...");
        executor.execute(() -> {
            try {
                URL u = new URL("https://api.open-meteo.com/v1/forecast?latitude=41.0082&longitude=28.9784&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto");
                HttpURLConnection c = (HttpURLConnection)u.openConnection();
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder s = new StringBuilder(); String line;
                while((line=br.readLine())!=null) s.append(line);
                JSONObject root = new JSONObject(s.toString());
                JSONObject cur = root.getJSONObject("current");
                double temp = cur.getDouble("temperature_2m");
                double wind = cur.getDouble("wind_speed_10m");
                int code = cur.getInt("weather_code");
                String desc = weatherText(code);
                runOnUiThread(() -> {
                    String out = String.format(Locale.US, "İstanbul: %.1f°C • %s • Rüzgâr %.0f km/sa", temp, desc, wind);
                    weather.setText(out);
                    speak("İstanbul'da hava " + String.format(Locale.US, "%.0f", temp) + " derece. " + desc + ".");
                });
            } catch(Exception e) {
                runOnUiThread(() -> {
                    weather.setText("Hava durumu alınamadı.");
                    speak("Hava durumuna ulaşamadım. İnternet bağlantını kontrol et.");
                });
            }
        });
    }

    private String weatherText(int c) {
        if (c == 0) return "açık";
        if (c <= 3) return "parçalı bulutlu";
        if (c <= 48) return "sisli";
        if (c <= 67) return "yağmurlu";
        if (c <= 77) return "kar ihtimali";
        if (c <= 82) return "sağanak";
        if (c <= 86) return "kar sağanağı";
        return "fırtınalı";
    }

    private void speak(String s) {
        status.setText(s);
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        executor.shutdownNow();
        super.onDestroy();
    }
}
